"""
Click here - Gemini 화면 안내 프로토타입 v3.4 UIA + 마지막 Vision 검증

이번 버전의 핵심 변경점:
1) 전체 화면 스크린샷을 Gemini Vision으로 매번 보내지 않습니다.
2) Windows UI Automation으로 현재 디스플레이에 보이는 버튼/입력창/링크/메뉴 등의 UI 요소 좌표를 먼저 추출합니다.
3) Gemini에게는 이미지가 아니라 UI 요소 목록 JSON만 보내고, Gemini는 target_id 하나만 고릅니다.
4) 오버레이는 Gemini가 찍은 추정 좌표가 아니라, 실제 UI 요소의 BoundingRectangle 좌표에 표시합니다.
5) Windows DPI/배율/해상도 차이를 자동으로 계산해 UIA 좌표를 PyQt 오버레이 좌표로 변환합니다.
6) 마지막 후보 상태라고 판단될 때만 스크린샷을 Gemini Vision으로 보내 목표 화면 도착 여부를 검증합니다.

주의:
- Windows 전용입니다.
- 앱/웹사이트가 접근성 정보를 제대로 제공하지 않으면 요소 추출이 적을 수 있습니다.
- 게임, 캔버스 기반 UI, 원격 데스크톱 화면처럼 UI Automation 정보가 없는 화면은 잘 안 잡힐 수 있습니다.
"""

from __future__ import annotations

import ctypes
import json
import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Any

from PyQt6.QtCore import Qt, QRect, QPoint, QTimer
from PyQt6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QGuiApplication
from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QMessageBox,
)

try:
    from dotenv import load_dotenv
except Exception:
    load_dotenv = None

try:
    from google import genai
    from google.genai import types as genai_types
except Exception:
    genai = None
    genai_types = None

try:
    import uiautomation as auto
except Exception:
    auto = None

try:
    import psutil
except Exception:
    psutil = None


APP_DIR = Path(__file__).resolve().parent
ENV_PATH = APP_DIR / ".env"
KEY_PATH = APP_DIR / ".gemini_key"


def enable_windows_dpi_awareness() -> None:
    """UIA 좌표와 PyQt 오버레이 좌표가 최대한 같은 기준을 쓰도록 DPI awareness를 켭니다."""
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def get_native_virtual_screen_rect() -> tuple[int, int, int, int]:
    """
    Windows가 실제로 쓰는 전체 가상 화면 좌표를 가져옵니다.
    UI Automation의 BoundingRectangle은 보통 Windows 네이티브/물리 픽셀 좌표를 반환합니다.
    """
    if sys.platform == "win32":
        try:
            user32 = ctypes.windll.user32
            x = int(user32.GetSystemMetrics(76))   # SM_XVIRTUALSCREEN
            y = int(user32.GetSystemMetrics(77))   # SM_YVIRTUALSCREEN
            w = int(user32.GetSystemMetrics(78))   # SM_CXVIRTUALSCREEN
            h = int(user32.GetSystemMetrics(79))   # SM_CYVIRTUALSCREEN
            if w > 0 and h > 0:
                return x, y, w, h
        except Exception:
            pass

    geometry = QGuiApplication.primaryScreen().virtualGeometry()
    return geometry.x(), geometry.y(), geometry.width(), geometry.height()


@dataclass
class UIElement:
    id: int
    name: str
    role: str
    rect: tuple[int, int, int, int]
    app: str = ""
    class_name: str = ""
    automation_id: str = ""
    depth: int = 0

    @property
    def center(self) -> tuple[int, int]:
        x, y, w, h = self.rect
        return (x + w // 2, y + h // 2)

    def compact(self) -> dict[str, Any]:
        x, y, w, h = self.rect
        cx, cy = self.center
        return {
            "id": self.id,
            "name": self.name[:120],
            "role": self.role,
            "app": self.app[:60],
            "rect": [x, y, w, h],
            "center": [cx, cy],
        }


@dataclass
class ScreenState:
    elements: list[UIElement]
    virtual_x: int
    virtual_y: int
    virtual_w: int
    virtual_h: int
    active_window: str = ""

    def summary(self) -> dict[str, Any]:
        apps: dict[str, int] = {}
        roles: dict[str, int] = {}
        visible_names: list[str] = []

        for e in self.elements:
            if e.app:
                apps[e.app] = apps.get(e.app, 0) + 1
            if e.role:
                roles[e.role] = roles.get(e.role, 0) + 1
            if e.name and len(visible_names) < 40:
                visible_names.append(e.name[:60])

        return {
            "active_window_hint": self.active_window,
            "apps": sorted(apps.items(), key=lambda x: -x[1])[:12],
            "roles": sorted(roles.items(), key=lambda x: -x[1])[:12],
            "sample_visible_names": visible_names,
        }


@dataclass
class GuidanceResult:
    instruction: str
    reason: str
    bbox: Optional[tuple[int, int, int, int]] = None
    target_point: Optional[tuple[int, int]] = None
    confidence: str = "medium"
    target_id: Optional[int] = None
    target_name: str = ""
    target_role: str = ""
    virtual_x: int = 0
    virtual_y: int = 0
    virtual_w: int = 1
    virtual_h: int = 1


@dataclass
class GuidanceStep:
    instruction: str
    target_name: str = ""
    target_role: str = ""
    rect: Optional[tuple[int, int, int, int]] = None
    confidence: str = "medium"

    def compact(self) -> dict[str, Any]:
        return {
            "instruction": self.instruction[:140],
            "target_name": self.target_name[:100],
            "target_role": self.target_role,
            "rect": list(self.rect) if self.rect else None,
            "confidence": self.confidence,
        }


class UIAutomationExtractor:
    """현재 디스플레이에 보이는 UI 요소를 Windows UI Automation으로 추출합니다."""

    USEFUL_ROLES = {
        "ButtonControl", "EditControl", "HyperlinkControl", "MenuItemControl",
        "ListItemControl", "TabItemControl", "CheckBoxControl", "RadioButtonControl",
        "ComboBoxControl", "SplitButtonControl", "TreeItemControl", "DataItemControl",
        "TextControl", "WindowControl", "PaneControl", "ToolBarControl",
        "DocumentControl", "CustomControl", "GroupControl", "ImageControl",
    }

    CLICKABLE_ROLES = {
        "ButtonControl", "EditControl", "HyperlinkControl", "MenuItemControl",
        "ListItemControl", "TabItemControl", "CheckBoxControl", "RadioButtonControl",
        "ComboBoxControl", "SplitButtonControl", "TreeItemControl", "DataItemControl",
    }

    def __init__(self, max_depth: int = 10, max_elements: int = 320):
        if auto is None:
            raise RuntimeError("uiautomation 패키지가 설치되지 않았습니다. pip install uiautomation 을 실행하세요.")
        self.max_depth = max_depth
        self.max_elements = max_elements
        self._process_name_cache: dict[int, str] = {}

    def extract(self) -> ScreenState:
        vx, vy, vw, vh = get_native_virtual_screen_rect()
        elements: list[UIElement] = []

        active_window_name = ""
        try:
            focused = auto.GetFocusedControl()
            if focused:
                active_window_name = self._safe_str(getattr(focused, "Name", ""))
        except Exception:
            pass

        root = auto.GetRootControl()
        try:
            top_windows = root.GetChildren()
        except Exception:
            top_windows = []

        next_id = 1
        for win in top_windows:
            if len(elements) >= self.max_elements:
                break
            next_id = self._walk(win, elements, next_id, 0, vx, vy, vw, vh)

        elements = self._dedupe_and_filter(elements, vx, vy, vw, vh)
        elements = elements[: self.max_elements]

        elements = [
            UIElement(
                id=i + 1,
                name=e.name,
                role=e.role,
                rect=e.rect,
                app=e.app,
                class_name=e.class_name,
                automation_id=e.automation_id,
                depth=e.depth,
            )
            for i, e in enumerate(elements)
        ]

        return ScreenState(
            elements=elements,
            virtual_x=vx,
            virtual_y=vy,
            virtual_w=vw,
            virtual_h=vh,
            active_window=active_window_name,
        )

    def _walk(
        self,
        control,
        elements: list[UIElement],
        next_id: int,
        depth: int,
        vx: int,
        vy: int,
        vw: int,
        vh: int,
    ) -> int:
        if len(elements) >= self.max_elements * 3 or depth > self.max_depth:
            return next_id

        try:
            role = self._safe_str(getattr(control, "ControlTypeName", ""))
            name = self._safe_str(getattr(control, "Name", ""))
            class_name = self._safe_str(getattr(control, "ClassName", ""))
            automation_id = self._safe_str(getattr(control, "AutomationId", ""))
            rect = getattr(control, "BoundingRectangle", None)
        except Exception:
            return next_id

        parsed_rect = self._parse_rect(rect)
        if parsed_rect and self._intersects(parsed_rect, vx, vy, vw, vh):
            if self._should_keep(role, name, class_name, parsed_rect, vx, vy, vw, vh):
                pid = 0
                try:
                    pid = int(getattr(control, "ProcessId", 0) or 0)
                except Exception:
                    pid = 0

                elements.append(
                    UIElement(
                        id=next_id,
                        name=name or automation_id or class_name or role,
                        role=role,
                        rect=parsed_rect,
                        app=self._process_name(pid),
                        class_name=class_name,
                        automation_id=automation_id,
                        depth=depth,
                    )
                )
                next_id += 1

        if depth >= self.max_depth or len(elements) >= self.max_elements * 3:
            return next_id

        try:
            children = control.GetChildren()
        except Exception:
            children = []

        for child in children:
            if len(elements) >= self.max_elements * 3:
                break
            next_id = self._walk(child, elements, next_id, depth + 1, vx, vy, vw, vh)

        return next_id

    @staticmethod
    def _safe_str(value: Any) -> str:
        try:
            return str(value or "").strip().replace("\n", " ").replace("\r", " ")
        except Exception:
            return ""

    @staticmethod
    def _parse_rect(rect: Any) -> Optional[tuple[int, int, int, int]]:
        if rect is None:
            return None
        try:
            left = int(rect.left)
            top = int(rect.top)
            right = int(rect.right)
            bottom = int(rect.bottom)
        except Exception:
            try:
                left, top, right, bottom = map(int, rect)
            except Exception:
                return None

        w = right - left
        h = bottom - top
        if w <= 0 or h <= 0:
            return None
        return left, top, w, h

    @staticmethod
    def _intersects(rect: tuple[int, int, int, int], vx: int, vy: int, vw: int, vh: int) -> bool:
        x, y, w, h = rect
        return not (x + w < vx or x > vx + vw or y + h < vy or y > vy + vh)

    def _should_keep(
        self,
        role: str,
        name: str,
        class_name: str,
        rect: tuple[int, int, int, int],
        vx: int,
        vy: int,
        vw: int,
        vh: int,
    ) -> bool:
        x, y, w, h = rect

        if w < 8 or h < 8:
            return False
        if not role:
            return False

        ignore_text = f"{name} {class_name}".lower()
        if "click here" in ignore_text or "gemini 화면 안내" in ignore_text:
            return False

        if role in self.CLICKABLE_ROLES:
            return True

        if role == "WindowControl":
            return bool(name) and w > 80 and h > 50

        if role in {
            "TextControl", "PaneControl", "ToolBarControl", "DocumentControl",
            "CustomControl", "GroupControl", "ImageControl",
        }:
            if not name:
                return False
            if w > vw * 0.85 and h > vh * 0.65:
                return False
            return True

        return role in self.USEFUL_ROLES and bool(name)

    def _dedupe_and_filter(
        self,
        elements: list[UIElement],
        vx: int,
        vy: int,
        vw: int,
        vh: int,
    ) -> list[UIElement]:
        seen: set[tuple[str, str, tuple[int, int, int, int]]] = set()
        out: list[UIElement] = []

        for e in elements:
            key = (e.name.lower(), e.role, e.rect)
            if key in seen:
                continue
            seen.add(key)
            out.append(e)

        def sort_key(e: UIElement):
            clickable = 0 if e.role in self.CLICKABLE_ROLES else 1
            named = 0 if e.name else 1
            area = e.rect[2] * e.rect[3]
            huge = 1 if area > (vw * vh * 0.20) else 0
            return clickable, named, huge, e.depth, area

        out.sort(key=sort_key)
        return out

    def _process_name(self, pid: int) -> str:
        if not pid:
            return ""
        if pid in self._process_name_cache:
            return self._process_name_cache[pid]

        name = ""
        if psutil is not None:
            try:
                name = psutil.Process(pid).name()
            except Exception:
                name = ""

        self._process_name_cache[pid] = name
        return name


class GeminiUIPlanner:
    """Gemini에게 UI 요소 목록을 주고, 다음에 눌러야 할 요소 id 하나를 고르게 합니다."""

    def __init__(self, api_key: str, model_name: str = "gemini-2.5-flash"):
        if genai is None:
            raise RuntimeError("google-genai 패키지가 설치되지 않았습니다. pip install google-genai 을 실행하세요.")
        self.client = genai.Client(api_key=api_key)
        self.model_name = model_name

    def plan(
        self,
        question: str,
        state: ScreenState,
        previous_steps: Optional[list[GuidanceStep]] = None,
    ) -> GuidanceResult:
        if not state.elements:
            return GuidanceResult(
                instruction="현재 화면에서 누를 수 있는 요소를 찾지 못했어요. 창을 한 번 클릭한 뒤 다시 안내를 눌러 주세요.",
                reason="UI Automation으로 추출된 요소가 없습니다.",
                confidence="low",
                virtual_x=state.virtual_x,
                virtual_y=state.virtual_y,
                virtual_w=state.virtual_w,
                virtual_h=state.virtual_h,
            )

        compact_elements = [
            e.compact()
            for e in self._rank_elements(question, state.elements, previous_steps)[:180]
        ]

        previous_steps = previous_steps or []
        previous_steps_json = json.dumps([s.compact() for s in previous_steps[-10:]], ensure_ascii=False)
        screen_summary_json = json.dumps(state.summary(), ensure_ascii=False)
        is_next_step = bool(previous_steps)

        prompt = f"""
너는 지적장애 사용자를 위한 컴퓨터 화면 안내 도우미다.
아래는 현재 전체 디스플레이에서 Windows UI Automation으로 추출한 실제 UI 요소 목록이다.
이미지 좌표를 추측하지 말고, 클릭 안내가 필요하면 반드시 elements 안의 target_id 하나만 골라라.

가장 중요한 판단 방식:
- previous_steps는 '이미 했다고 무조건 가정'하는 용도가 아니다.
- previous_steps는 사용자가 앞에서 어떤 안내를 받았는지 알려주는 기록이다.
- 너는 previous_steps와 현재 화면 요소 목록을 비교해서 실제로 화면이 다음 상태로 바뀌었는지 판단해야 한다.
- 현재 화면이 이전 단계 이후 바뀐 증거가 있으면 다음 단계로 진행한다.
- 현재 화면이 바뀌지 않았거나 목표 앱/요소가 아직 안 보이면 같은 행동을 반복할 수 있다. 단, 왜 다시 해야 하는지 instruction에 다르게 설명한다.
- 이전 안내와 완전히 같은 문장을 기계적으로 반복하지 마라.

규칙:
1. 사용자에게 한 번에 하나의 행동만 안내한다.
2. 좌표를 새로 만들지 말고, elements 안에 있는 id만 선택한다.
3. 확실하지 않거나 관련 요소가 없으면 target_id를 null로 둔다.
4. 개인정보 입력, 결제, 삭제, 전송, 파일 삭제 같은 위험 행동은 직접 클릭을 유도하지 말고 target_id를 null로 둔다.
5. 이 프로그램의 안내창/오버레이가 후보에 있더라도 실제 작업 대상이 아니면 선택하지 않는다.
6. 주소창/검색창/입력칸에 무언가 입력해야 하는 상황이면 해당 EditControl을 선택한다.
7. 앱을 열어야 하는 상황이면 작업 표시줄/시작 메뉴/바탕화면의 관련 앱 버튼 또는 검색창을 선택한다.
8. 다음 행동이 키보드 입력/Enter 누르기처럼 특정 클릭 좌표가 필요 없는 행동이면 target_id를 null로 두고 instruction에 그 행동을 명확히 써라.
9. Chrome/브라우저가 이미 열린 상태이고 사용자가 유튜브에 가려는 경우, 주소창이나 검색창이 보이면 그것을 고르고 instruction은 '주소창에 youtube.com을 입력하고 Enter를 누르세요'처럼 입력까지 포함해라.
10. 주소창/검색창 요소가 UIA 목록에 없지만 Chrome/브라우저가 열린 증거가 있으면 target_id를 null로 두고 'Ctrl+L을 누른 뒤 youtube.com을 입력하고 Enter를 누르세요'라고 안내해라.
11. 사용자가 앞 단계에서 Chrome을 열라는 안내를 받았고 현재 화면 요약에 Chrome/브라우저 요소가 보이면 Chrome 열기 안내를 반복하지 말고 주소창/입력 단계로 넘어가라.
12. 유튜브 검색 결과나 YouTube 링크/탭/버튼이 보이면 그 요소를 우선 선택한다.
13. 작업이 이미 완료된 것으로 보이면 target_id를 null로 두고 완료 안내를 해라.

다음 단계 모드: {is_next_step}

이전 안내 기록 JSON:
{previous_steps_json}

현재 화면 요약 JSON:
{screen_summary_json}

사용자 질문:
{question}

디스플레이 영역:
x={state.virtual_x}, y={state.virtual_y}, width={state.virtual_w}, height={state.virtual_h}

요소 목록 JSON:
{json.dumps(compact_elements, ensure_ascii=False)}

반드시 아래 JSON만 출력해라. 마크다운 금지.
{{
  "instruction": "사용자에게 보여줄 쉬운 한국어 안내문",
  "reason": "현재 화면과 이전 안내 기록을 비교해서 왜 이 다음 행동인지 짧게",
  "target_id": 1,
  "confidence": "high|medium|low"
}}

누를 요소가 없으면 target_id는 null로 둔다.
""".strip()

        response = self.client.models.generate_content(
            model=self.model_name,
            contents=prompt,
        )

        text = getattr(response, "text", None) or ""
        data = self._extract_json(text)

        target_id = self._parse_target_id(data.get("target_id"))
        confidence = str(data.get("confidence", "medium")).lower().strip()
        if confidence not in {"high", "medium", "low"}:
            confidence = "medium"

        selected = next((e for e in state.elements if e.id == target_id), None) if target_id else None

        forced = self._browser_addressbar_fallback(question, state, previous_steps, selected)
        if forced is not None:
            selected, forced_instruction, forced_reason = forced
            target_id = selected.id if selected else None
            data["instruction"] = forced_instruction
            data["reason"] = forced_reason
            confidence = "high" if selected else "medium"

        bbox = selected.rect if selected and confidence != "low" else None
        target_point = selected.center if selected and confidence != "low" else None

        return GuidanceResult(
            instruction=str(data.get("instruction", "화면을 다시 확인해 주세요."))[:160],
            reason=str(data.get("reason", ""))[:260],
            bbox=bbox,
            target_point=target_point,
            confidence=confidence,
            target_id=target_id if selected else None,
            target_name=selected.name if selected else "",
            target_role=selected.role if selected else "",
            virtual_x=state.virtual_x,
            virtual_y=state.virtual_y,
            virtual_w=state.virtual_w,
            virtual_h=state.virtual_h,
        )

    @staticmethod
    def _rank_elements(
        question: str,
        elements: list[UIElement],
        previous_steps: Optional[list[GuidanceStep]] = None,
    ) -> list[UIElement]:
        q = question.lower()
        previous_steps = previous_steps or []
        prev_text = " ".join([s.instruction + " " + s.target_name for s in previous_steps[-5:]]).lower()

        extra_keywords = []

        if any(k in q for k in ["유튜브", "youtube", "영상"]):
            extra_keywords += [
                "youtube", "유튜브", "chrome", "크롬", "주소", "주소창",
                "검색", "search", "google", "omnibox", "address", "url",
                "새 탭", "new tab",
            ]

        if any(k in q for k in ["인터넷", "크롬", "chrome", "구글"]):
            extra_keywords += ["chrome", "크롬", "edge", "주소", "검색", "google", "internet"]

        if any(k in q for k in ["파일", "폴더", "탐색기"]):
            extra_keywords += ["file", "explorer", "파일", "폴더", "탐색기"]

        if any(k in q for k in ["설정", "와이파이", "wifi", "블루투스"]):
            extra_keywords += ["settings", "설정", "wifi", "wi-fi", "bluetooth", "블루투스"]

        tokens = [t for t in re.split(r"[^0-9a-zA-Z가-힣]+", q) if len(t) >= 2]
        tokens += extra_keywords
        tokens = list(dict.fromkeys(tokens))

        clickable_roles = UIAutomationExtractor.CLICKABLE_ROLES

        def score(e: UIElement) -> int:
            text = f"{e.name} {e.role} {e.app} {e.class_name} {e.automation_id}".lower()
            s = 0

            if e.role in clickable_roles:
                s += 30
            if e.role == "EditControl":
                s += 35
            if e.name:
                s += 8

            for t in tokens:
                if t.lower() in text:
                    s += 50

            if any(k in q for k in ["유튜브", "youtube", "구글", "인터넷", "크롬", "chrome"]):
                if any(
                    k in text
                    for k in [
                        "chrome", "msedge", "edge", "browser", "크롬",
                        "주소", "address", "omnibox", "url", "검색",
                        "search", "google", "youtube", "유튜브",
                    ]
                ):
                    s += 40
                if e.role == "EditControl":
                    s += 35

            if any(k in prev_text for k in ["크롬", "chrome", "브라우저", "인터넷", "열"]):
                if e.role == "EditControl" or any(k in text for k in ["주소", "address", "omnibox", "search", "검색"]):
                    s += 55

            if any(k in text for k in ["start", "시작", "taskbar", "작업 표시줄"]):
                s += 10

            area = e.rect[2] * e.rect[3]
            if area > 800_000:
                s -= 25

            s -= min(e.depth, 10)
            return -s

        return sorted(elements, key=score)

    @staticmethod
    def _browser_addressbar_fallback(
        question: str,
        state: ScreenState,
        previous_steps: Optional[list[GuidanceStep]],
        selected: Optional[UIElement],
    ) -> Optional[tuple[Optional[UIElement], str, str]]:
        q = question.lower()
        if not any(k in q for k in ["유튜브", "youtube"]):
            return None

        elements = state.elements
        text_all = " ".join(
            f"{e.name} {e.role} {e.app} {e.class_name} {e.automation_id}"
            for e in elements
        ).lower()

        browser_visible = any(
            any(k in f"{e.app} {e.name} {e.class_name}".lower() for k in ["chrome.exe", "msedge.exe", "firefox.exe"])
            or (
                e.role in {"WindowControl", "DocumentControl", "PaneControl", "EditControl"}
                and any(
                    k in f"{e.name} {e.app} {e.class_name}".lower()
                    for k in ["chrome", "msedge", "edge", "firefox", "browser", "크롬", "google chrome"]
                )
            )
            for e in elements
        )

        youtube_visible = any(k in text_all for k in ["youtube", "유튜브", "youtube.com", "www.youtube.com"])

        if selected:
            selected_text = f"{selected.name} {selected.app} {selected.role}".lower()
            if any(k in selected_text for k in ["youtube", "유튜브", "주소", "address", "omnibox", "search", "검색"]):
                return None

        if youtube_visible:
            search_boxes = [
                e for e in elements
                if e.role == "EditControl"
                and any(
                    k in f"{e.name} {e.automation_id} {e.class_name}".lower()
                    for k in ["search", "검색"]
                )
            ]
            if search_boxes:
                e = sorted(search_boxes, key=lambda x: (x.rect[1], x.rect[0]))[0]
                return e, "YouTube 검색창에 보고 싶은 영상을 입력하세요.", "현재 YouTube 화면으로 판단되어 검색창을 선택했습니다."

            candidates = [
                e for e in elements
                if any(k in f"{e.name} {e.app}".lower() for k in ["youtube", "유튜브"])
            ]
            clickable = [
                e for e in candidates
                if e.role in UIAutomationExtractor.CLICKABLE_ROLES
                or e.role in {"TextControl", "CustomControl", "DocumentControl"}
            ]
            if clickable:
                e = sorted(clickable, key=lambda x: (0 if x.role in UIAutomationExtractor.CLICKABLE_ROLES else 1, x.rect[1], x.rect[0]))[0]
                return e, "화면에 보이는 YouTube를 클릭하세요.", "현재 화면에 YouTube 관련 요소가 보여서 그 요소를 선택했습니다."

        if browser_visible:
            edit_controls = [e for e in elements if e.role == "EditControl"]

            def edit_score(e: UIElement) -> int:
                text = f"{e.name} {e.app} {e.class_name} {e.automation_id}".lower()
                score = 0

                if any(k in text for k in ["주소", "address", "omnibox", "url"]):
                    score += 120
                if any(k in text for k in ["검색", "search", "google"]):
                    score += 80

                x, y, w, h = e.rect
                if y < state.virtual_y + max(180, int(state.virtual_h * 0.22)):
                    score += 30
                if w > 250:
                    score += 20
                if any(k in text for k in ["chrome", "edge", "browser", "크롬"]):
                    score += 20

                return -score

            if edit_controls:
                e = sorted(edit_controls, key=edit_score)[0]
                return e, "주소창에 youtube.com을 입력하고 Enter를 누르세요.", "브라우저가 열린 상태이고 입력 가능한 주소창/검색창 후보가 보여서 다음 단계로 판단했습니다."

            return None, "Ctrl+L을 누른 뒤 youtube.com을 입력하고 Enter를 누르세요.", "브라우저는 보이지만 UI Automation에서 주소창 요소를 정확히 찾지 못해 키보드 단축키 안내로 보정했습니다."

        return None

    @staticmethod
    def _parse_target_id(value: Any) -> Optional[int]:
        if value is None:
            return None
        try:
            if isinstance(value, str) and value.lower().strip() in {"null", "none", ""}:
                return None
            n = int(float(value))
            return n if n > 0 else None
        except Exception:
            return None

    @staticmethod
    def _extract_json(text: str) -> dict:
        text = text.strip()

        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?", "", text).strip()
            text = re.sub(r"```$", "", text).strip()

        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            text = match.group(0)

        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Gemini 응답을 JSON으로 해석하지 못했습니다. 원문: {text[:500]}") from exc


class VisionScreenVerifier:
    """
    마지막 후보 상태에서만 스크린샷으로 목표 화면 도착 여부를 검증합니다.

    중요:
    - 좌표를 찍거나 클릭 대상을 고르는 용도가 아닙니다.
    - UIA가 약한 웹페이지 내부 상태, 예: YouTube 메인 화면 도착 여부만 확인합니다.
    """

    def __init__(self, api_key: str, model_name: str = "gemini-2.5-flash"):
        if genai is None or genai_types is None:
            raise RuntimeError("google-genai 패키지가 설치되지 않았습니다. pip install google-genai 을 실행하세요.")
        self.client = genai.Client(api_key=api_key)
        self.model_name = model_name

    def verify_goal_screen(
        self,
        question: str,
        state: ScreenState,
        previous_steps: Optional[list[GuidanceStep]] = None,
    ) -> dict[str, Any]:
        png_bytes = self._grab_screen_png_bytes()
        if not png_bytes:
            return {
                "is_goal_screen": False,
                "confidence": "low",
                "reason": "스크린샷을 가져오지 못했습니다.",
                "next_instruction": "화면을 다시 확인해 주세요.",
            }

        previous_steps = previous_steps or []
        previous_steps_json = json.dumps([s.compact() for s in previous_steps[-8:]], ensure_ascii=False)
        screen_summary_json = json.dumps(state.summary(), ensure_ascii=False)

        prompt = f"""
너는 컴퓨터 화면 안내 프로그램의 마지막 검증기다.
사용자는 지적장애가 있을 수 있으므로 쉽고 짧게 안내해야 한다.

너의 역할:
- 스크린샷을 보고 사용자의 목표 화면에 도착했는지 확인한다.
- 클릭 좌표나 bbox를 만들지 않는다.
- 버튼을 누를 대상을 고르지 않는다.
- 목표 화면이면 완료/다음 행동 안내를 한다.
- 목표 화면이 아니면 아직 도착하지 않았다고 말한다.

판단 기준:
1. 사용자가 유튜브/YouTube에 가려고 했다면, YouTube 로고, 검색창, 영상 썸네일, 좌측 메뉴, 주소/탭 제목 등으로 YouTube 화면인지 판단한다.
2. 브라우저 로딩 중이거나 새 탭/구글 검색 화면이면 목표 화면이 아니다.
3. 화면에 개인정보, 결제, 삭제, 전송 같은 위험 행동이 보이면 직접 누르라고 하지 않는다.
4. 확실하지 않으면 is_goal_screen은 false로 둔다.

사용자 목표:
{question}

이전 안내 기록 JSON:
{previous_steps_json}

현재 UIA 화면 요약 JSON:
{screen_summary_json}

반드시 아래 JSON만 출력해라. 마크다운 금지.
{{
  "is_goal_screen": true,
  "confidence": "high|medium|low",
  "reason": "왜 목표 화면이라고 판단했는지 또는 아닌지 짧게",
  "next_instruction": "사용자에게 보여줄 쉬운 한국어 안내문"
}}
""".strip()

        response = self.client.models.generate_content(
            model=self.model_name,
            contents=[
                prompt,
                genai_types.Part.from_bytes(data=png_bytes, mime_type="image/png"),
            ],
        )

        text = getattr(response, "text", None) or ""
        data = GeminiUIPlanner._extract_json(text)

        confidence = str(data.get("confidence", "medium")).lower().strip()
        if confidence not in {"high", "medium", "low"}:
            confidence = "medium"

        return {
            "is_goal_screen": bool(data.get("is_goal_screen", False)),
            "confidence": confidence,
            "reason": str(data.get("reason", ""))[:260],
            "next_instruction": str(data.get("next_instruction", "화면을 확인해 주세요."))[:160],
        }

    @staticmethod
    def _grab_screen_png_bytes() -> bytes:
        screen = QGuiApplication.primaryScreen()
        if screen is None:
            return b""

        pixmap = screen.grabWindow(0)
        if pixmap.isNull():
            return b""

        tmp_path = APP_DIR / "_vision_check_screen.png"
        try:
            pixmap.save(str(tmp_path), "PNG")
            return tmp_path.read_bytes()
        finally:
            try:
                tmp_path.unlink(missing_ok=True)
            except Exception:
                pass


class OverlayRenderer(QWidget):
    """클릭을 방해하지 않는 투명 오버레이입니다."""

    def __init__(self):
        super().__init__()
        self.result: Optional[GuidanceResult] = None
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._fit_to_virtual_screen()

    def _fit_to_virtual_screen(self):
        geometry = QGuiApplication.primaryScreen().virtualGeometry()
        self.setGeometry(geometry)

    def show_guidance(self, result: GuidanceResult):
        self._fit_to_virtual_screen()
        self.result = result
        self.show()
        self.raise_()
        self.update()

    def clear(self):
        self.result = None
        self.hide()

    def _scale_factors(self) -> tuple[float, float]:
        assert self.result is not None
        sx = self.width() / max(1, self.result.virtual_w)
        sy = self.height() / max(1, self.result.virtual_h)
        return sx, sy

    def _map_rect_to_overlay(self, bbox: tuple[int, int, int, int]) -> QRect:
        assert self.result is not None

        x, y, w, h = bbox
        sx, sy = self._scale_factors()

        ox = round((x - self.result.virtual_x) * sx)
        oy = round((y - self.result.virtual_y) * sy)
        ow = max(4, round(w * sx))
        oh = max(4, round(h * sy))

        return QRect(ox, oy, ow, oh)

    def _map_point_to_overlay(self, point: tuple[int, int]) -> QPoint:
        assert self.result is not None

        x, y = point
        sx, sy = self._scale_factors()

        return QPoint(
            round((x - self.result.virtual_x) * sx),
            round((y - self.result.virtual_y) * sy),
        )

    def paintEvent(self, event):
        if not self.result:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        painter.fillRect(self.rect(), QColor(0, 0, 0, 18))

        font = QFont("Malgun Gothic", 14)
        font.setBold(True)
        painter.setFont(font)

        if self.result.bbox:
            rect = self._map_rect_to_overlay(self.result.bbox)

            painter.setPen(QPen(QColor(255, 180, 0), 5))
            painter.setBrush(QBrush(QColor(255, 220, 0, 45)))
            painter.drawRoundedRect(rect, 10, 10)

            if self.result.target_point:
                center = self._map_point_to_overlay(self.result.target_point)
            else:
                center = rect.center()

            painter.setPen(QPen(QColor(255, 60, 60), 4))
            painter.drawLine(center.x() - 18, center.y(), center.x() + 18, center.y())
            painter.drawLine(center.x(), center.y() - 18, center.x(), center.y() + 18)

            painter.setBrush(QBrush(QColor(255, 60, 60, 210)))
            painter.drawEllipse(center, 7, 7)

            start = QPoint(max(20, center.x() - 160), max(40, center.y() - 120))
            painter.setPen(QPen(QColor(255, 80, 80), 5))
            painter.drawLine(start, center)

            bubble_x = max(10, min(start.x() - 20, self.width() - 470))
            bubble_y = max(10, min(start.y() - 70, self.height() - 140))
        else:
            bubble_x = self.width() // 2 - 235
            bubble_y = 60

        bubble = QRect(bubble_x, bubble_y, 470, 110)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor(255, 255, 255, 242)))
        painter.drawRoundedRect(bubble, 18, 18)

        painter.setPen(QPen(QColor(20, 20, 20), 2))
        painter.drawText(
            bubble.adjusted(18, 10, -18, -10),
            Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap,
            self.result.instruction,
        )


class ChatWidget(QWidget):
    """오른쪽 아래에 표시되는 질문 입력창입니다."""

    def __init__(self):
        super().__init__()

        self.extractor = UIAutomationExtractor()
        self.overlay = OverlayRenderer()
        self.last_question = ""
        self.step_history: list[GuidanceStep] = []

        self.setWindowTitle("Click here")
        self.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setMinimumWidth(470)
        self.setStyleSheet("""
            QWidget { font-family: 'Malgun Gothic'; font-size: 13px; }
            QLineEdit, QTextEdit {
                border: 1px solid #cfcfcf;
                border-radius: 8px;
                padding: 7px;
                background: white;
            }
            QPushButton {
                border: 0;
                border-radius: 8px;
                padding: 8px 10px;
                background: #246BFE;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover { background: #1d58d0; }
            QPushButton#sub { background: #666; }
            QPushButton#danger { background: #B23B3B; }
            QLabel#title { font-size: 15px; font-weight: bold; }
            QLabel#hint { color: #555; }
        """)

        self._build_ui()
        QTimer.singleShot(100, self._move_bottom_right)

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Click here 화면 안내 v3.4 - UIA + 마지막 Vision 검증")
        title.setObjectName("title")
        layout.addWidget(title)

        self.key_input = QLineEdit()
        self.key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_input.setPlaceholderText("Gemini API Key 입력")
        self.key_input.setText(self._load_key())

        key_row = QHBoxLayout()
        key_row.addWidget(self.key_input)

        save_btn = QPushButton("저장")
        save_btn.clicked.connect(self._save_key)
        key_row.addWidget(save_btn)

        layout.addLayout(key_row)

        self.model_input = QLineEdit("gemini-2.5-flash")
        self.model_input.setPlaceholderText("모델명 예: gemini-2.5-flash")
        layout.addWidget(self.model_input)

        self.question_input = QLineEdit()
        self.question_input.setPlaceholderText("예: 유튜브에 어떻게 들어가?")
        self.question_input.returnPressed.connect(self.guide)
        layout.addWidget(self.question_input)

        row = QHBoxLayout()

        guide_btn = QPushButton("안내")
        guide_btn.clicked.connect(self.guide)
        row.addWidget(guide_btn)

        next_btn = QPushButton("다음 단계")
        next_btn.setObjectName("sub")
        next_btn.clicked.connect(self.next_step)
        row.addWidget(next_btn)

        clear_btn = QPushButton("지우기")
        clear_btn.setObjectName("danger")
        clear_btn.clicked.connect(self.overlay.clear)
        row.addWidget(clear_btn)

        layout.addLayout(row)

        hint = QLabel("기본은 UIA 좌표 안내, 마지막 후보 상태에서만 스크린샷 Vision 검증")
        hint.setObjectName("hint")
        layout.addWidget(hint)

        self.status = QTextEdit()
        self.status.setReadOnly(True)
        self.status.setFixedHeight(132)
        self.status.setPlaceholderText("안내 결과가 여기에 표시됩니다.")
        layout.addWidget(self.status)

    def _move_bottom_right(self):
        screen = QGuiApplication.primaryScreen().availableGeometry()
        self.resize(500, 292)
        self.move(screen.right() - self.width() - 20, screen.bottom() - self.height() - 20)

    def _load_key(self) -> str:
        if load_dotenv and ENV_PATH.exists():
            load_dotenv(ENV_PATH)

        env_key = os.getenv("GEMINI_API_KEY", "")
        if env_key and env_key != "your_key_here":
            return env_key

        if KEY_PATH.exists():
            return KEY_PATH.read_text(encoding="utf-8").strip()

        return ""

    def _save_key(self):
        key = self.key_input.text().strip()
        if not key:
            QMessageBox.warning(self, "키 없음", "Gemini API Key를 입력해 주세요.")
            return

        KEY_PATH.write_text(key, encoding="utf-8")
        self.status.setPlainText("Gemini API Key를 저장했습니다.")

    def _planner(self) -> GeminiUIPlanner:
        key = self.key_input.text().strip()
        if not key:
            raise RuntimeError("Gemini API Key를 먼저 입력하세요.")

        return GeminiUIPlanner(
            api_key=key,
            model_name=self.model_input.text().strip() or "gemini-2.5-flash",
        )

    def _vision_verifier(self) -> VisionScreenVerifier:
        key = self.key_input.text().strip()
        if not key:
            raise RuntimeError("Gemini API Key를 먼저 입력하세요.")

        return VisionScreenVerifier(
            api_key=key,
            model_name=self.model_input.text().strip() or "gemini-2.5-flash",
        )

    def guide(self):
        question = self.question_input.text().strip()
        if not question:
            QMessageBox.warning(self, "질문 없음", "질문을 입력해 주세요.")
            return

        self.step_history.clear()
        self.last_question = question
        self._run_guidance(question, is_next_step=False)

    def next_step(self):
        if not self.last_question:
            QMessageBox.warning(self, "이전 질문 없음", "먼저 질문을 입력하고 안내를 받아 주세요.")
            return

        self._run_guidance(self.last_question, is_next_step=True)

    def _should_run_vision_check(
        self,
        question: str,
        state: ScreenState,
        result: GuidanceResult,
        is_next_step: bool,
    ) -> tuple[bool, int, str]:
        """
        마지막 후보 상태인지 점수화합니다.
        2점 이상이면 Vision 검증을 실행합니다.
        """
        q = question.lower()

        if not any(k in q for k in ["유튜브", "youtube", "인터넷", "크롬", "chrome", "사이트", "웹"]):
            return False, 0, "웹/브라우저 목표가 아니라 Vision 검증 생략"

        score = 0
        reasons: list[str] = []

        elements_text = " ".join(
            f"{e.name} {e.role} {e.app} {e.class_name} {e.automation_id}"
            for e in state.elements
        ).lower()

        prev_text = " ".join(
            f"{s.instruction} {s.target_name} {s.target_role}"
            for s in self.step_history[-6:]
        ).lower()

        result_text = f"{result.instruction} {result.reason} {result.target_name} {result.target_role}".lower()

        if is_next_step:
            score += 1
            reasons.append("다음 단계 요청")

        if any(k in prev_text for k in ["youtube.com", "ctrl+l", "주소창", "enter", "엔터"]):
            score += 1
            reasons.append("이전 단계가 주소 입력/이동")

        browser_visible = any(
            k in elements_text
            for k in ["chrome.exe", "msedge.exe", "firefox.exe", "chrome", "edge", "browser", "크롬"]
        )
        if browser_visible:
            score += 1
            reasons.append("브라우저 요소 감지")

        if any(k in elements_text for k in ["youtube", "유튜브", "구독", "동영상", "shorts", "검색"]):
            score += 1
            reasons.append("YouTube/검색 관련 UIA 단서 감지")

        if result.target_id is None and any(k in result_text for k in ["완료", "도착", "화면", "보입니다", "검색창"]):
            score += 1
            reasons.append("UIA 결과가 완료/화면 상태를 암시")

        if any(k in result_text for k in ["youtube", "유튜브", "youtube.com"]):
            score += 1
            reasons.append("현재 안내에 YouTube 단서 포함")

        return score >= 2, score, ", ".join(reasons) if reasons else "단서 부족"

    def _apply_vision_result(
        self,
        vision: dict[str, Any],
        state: ScreenState,
    ) -> Optional[GuidanceResult]:
        """
        Vision이 목표 화면이라고 확인한 경우에만 기존 UIA 안내를 완료/다음 행동 안내로 교체합니다.
        """
        if not vision.get("is_goal_screen"):
            return None

        confidence = str(vision.get("confidence", "medium")).lower().strip()
        if confidence not in {"high", "medium", "low"}:
            confidence = "medium"

        if confidence == "low":
            return None

        return GuidanceResult(
            instruction=str(vision.get("next_instruction", "목표 화면에 도착했습니다."))[:160],
            reason=str(vision.get("reason", "Vision으로 목표 화면 도착을 확인했습니다."))[:260],
            bbox=None,
            target_point=None,
            confidence=confidence,
            target_id=None,
            target_name="Vision 화면 검증",
            target_role="ScreenVerification",
            virtual_x=state.virtual_x,
            virtual_y=state.virtual_y,
            virtual_w=state.virtual_w,
            virtual_h=state.virtual_h,
        )

    def _run_guidance(self, question: str, is_next_step: bool = False):
        try:
            mode_text = "다음 단계를 찾는 중입니다." if is_next_step else "첫 안내를 찾는 중입니다."
            self.status.setPlainText(
                f"{mode_text}\n"
                f"현재 디스플레이의 UI 요소를 추출하는 중입니다...\n"
                f"기본 단계에서는 이미지를 Gemini에 보내지 않습니다."
            )
            QApplication.processEvents()

            state = self.extractor.extract()

            self.status.setPlainText(
                f"UI 요소 {len(state.elements)}개 추출 완료.\n"
                f"Gemini가 현재 화면과 이전 안내 기록을 비교해 다음 행동을 판단 중입니다...\n"
                f"활성 힌트: {state.active_window}"
            )
            QApplication.processEvents()

            history_for_prompt = self.step_history if is_next_step else []
            result = self._planner().plan(question, state, history_for_prompt)

            vision_note = "Vision 검증 안 함"
            should_vision, vision_score, vision_reason = self._should_run_vision_check(
                question,
                state,
                result,
                is_next_step,
            )

            if should_vision:
                self.overlay.clear()
                QApplication.processEvents()

                self.status.setPlainText(
                    f"마지막 후보 상태로 판단했습니다. Vision 검증 중입니다...\n"
                    f"점수={vision_score} / 단서={vision_reason}"
                )
                QApplication.processEvents()

                vision = self._vision_verifier().verify_goal_screen(
                    question,
                    state,
                    self.step_history,
                )

                applied = self._apply_vision_result(vision, state)
                if applied is not None:
                    result = applied
                    vision_note = f"Vision 확인됨: {vision.get('reason', '')}"
                else:
                    vision_note = f"Vision 미확인: {vision.get('reason', '')}"
            else:
                vision_note = f"Vision 생략: 점수={vision_score}, 단서={vision_reason}"

            self._remember_step(result)
            self.overlay.show_guidance(result)

            if result.bbox:
                bbox_text = f"target_id={result.target_id}, bbox={result.bbox}, target={result.target_point}"
            else:
                bbox_text = "클릭 위치 없음"

            self.status.setPlainText(
                f"안내: {result.instruction}\n"
                f"신뢰도: {result.confidence} / {bbox_text}\n"
                f"선택 요소: {result.target_name}\n"
                f"추출 요소 수: {len(state.elements)} / "
                f"네이티브 디스플레이={state.virtual_w}x{state.virtual_h}, "
                f"오버레이={self.overlay.width()}x{self.overlay.height()}\n"
                f"Vision: {vision_note}\n"
                f"이유: {result.reason}"
            )

        except Exception as exc:
            self.overlay.clear()
            detail = traceback.format_exc(limit=2)
            self.status.setPlainText(f"오류: {exc}\n\n{detail}")
            QMessageBox.critical(self, "오류", str(exc))

    def _remember_step(self, result: GuidanceResult) -> None:
        if not result.instruction:
            return

        step = GuidanceStep(
            instruction=result.instruction,
            target_name=result.target_name,
            target_role=result.target_role,
            rect=result.bbox,
            confidence=result.confidence,
        )

        if self.step_history and self.step_history[-1].compact() == step.compact():
            return

        self.step_history.append(step)
        self.step_history = self.step_history[-10:]


def main():
    enable_windows_dpi_awareness()
    app = QApplication(sys.argv)
    widget = ChatWidget()
    widget.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()