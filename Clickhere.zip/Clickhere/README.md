# Click here - Gemini 화면 안내 프로토타입 v3.4

## 변경점
- 전체 스크린샷을 Gemini Vision으로 보내지 않고, Windows UI Automation으로 추출한 UI 요소 목록을 Gemini에 전달합니다.
- DPI/해상도 배율 차이를 자동 보정합니다.
- v3.4에서는 Chrome/Edge에서 YouTube 페이지에 이미 도착했는지 창 제목, 주소창 값, UI 요소 이름을 함께 보고 판단합니다.
- YouTube 화면에 도착했는데도 주소창 클릭을 반복하는 문제를 줄였습니다.

## 실행
1. `run.bat` 실행
2. Gemini API Key 입력 후 저장
3. 질문 입력 예: `유튜브에 어떻게 들어가?`
4. 안내에 따라 행동한 뒤 `다음 단계` 클릭

## 참고
Chrome 웹페이지 내부 요소가 잘 안 잡히면 Chrome 접근성 트리가 비활성화된 상태일 수 있습니다. 이 버전은 창 제목/주소창 값까지 보조 신호로 사용하지만, 일부 환경에서는 Chrome을 `--force-renderer-accessibility` 옵션으로 실행해야 웹페이지 내부 링크/버튼이 더 잘 잡힐 수 있습니다.
